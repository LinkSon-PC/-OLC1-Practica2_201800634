import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})

export class ObjetoHtml{
  HTML:string;
  JSON:string;
}

export class HtmlModule { 
  HTML:string;

  Objeto:ObjetoHtml = {
    HTML: "",
    JSON: ""
  }

  constructor(cadena:string){
    this.HTML = cadena;
    this.Objeto.HTML = "lasdjf";

  }

  ModificarHtml(html:string){
    let estado:number =0;
    let tabulador:number  =0;

    let cadena:string ="";

    for (let i = 0; i < html.length; i++) {
      switch(estado){
        case 0:
          cadena+="\n";
            this.Tab(tabulador, cadena);

          if(html[i] === "<"){
            tabulador++;
            estado =1;
          }else{
            estado =4;
          }
            cadena += html[i];
          break;
        case 1:
          if(html[i] === "/"){
            tabulador--;
          }
          cadena += html[i];
          estado =2;
          break;
        case 3:
          
          if(html[i] === ">"){
            estado =0;
          }else{
            estado =3;
          }
          cadena += html[i];
          break;

          case 4:
            cadena+="\n";
  
            if(html[i] === "<"){
              i--;
              estado =0;
            }else{
              cadena += html[i];
            }
            break;
      }
      
    }
  }

  Tab(salto:number, cadena:string){
    for (let i = 0; i < salto; i++) {
      cadena+="\t";
    }
  }
}
