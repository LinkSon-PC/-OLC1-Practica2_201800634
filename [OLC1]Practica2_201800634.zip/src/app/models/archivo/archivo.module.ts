import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class ArchivoModule {
  Nombre?:string;
  Contenido?:string;

  // constructor(nombre:string, contenido:string){
  //  this.Nombre= nombre;
  //  this.Contenido= contenido;
  //}
 }
